import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const rooms = pgTable("rooms", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  name: text("name").notNull(),
  dimensions: jsonb("dimensions").notNull(),
  image: text("image").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const furniture = pgTable("furniture", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  name: text("name").notNull(),
  dimensions: text("dimensions").notNull(),
  image: text("image").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const layouts = pgTable("layouts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  roomId: integer("room_id").references(() => rooms.id).notNull(),
  name: text("name").notNull(),
  furniturePositions: jsonb("furniture_positions").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
});

export const insertRoomSchema = createInsertSchema(rooms).pick({
  userId: true,
  name: true,
  dimensions: true,
  image: true,
});

export const insertFurnitureSchema = createInsertSchema(furniture).pick({
  userId: true,
  name: true,
  dimensions: true,
  image: true,
});

export const insertLayoutSchema = createInsertSchema(layouts).pick({
  userId: true,
  roomId: true,
  name: true,
  furniturePositions: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertRoom = z.infer<typeof insertRoomSchema>;
export type Room = typeof rooms.$inferSelect;

export type InsertFurniture = z.infer<typeof insertFurnitureSchema>;
export type Furniture = typeof furniture.$inferSelect;

export type InsertLayout = z.infer<typeof insertLayoutSchema>;
export type Layout = typeof layouts.$inferSelect;
