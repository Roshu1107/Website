import React from "react";
import HeroSection from "@/components/home/hero-section";
import FeaturesSection from "@/components/home/features-section";
import RoomScanner from "@/components/room-scanner/room-scanner";
import CtaSection from "@/components/home/cta-section";
import { Helmet } from "react-helmet";

export default function Home() {
  return (
    <>
      <Helmet>
        <title>RoomFit - AI-Powered Room Layout Planner</title>
        <meta name="description" content="RoomFit helps you plan perfect room layouts with AI-powered furniture placement, dimension estimation, and design recommendations." />
      </Helmet>
      
      <HeroSection />
      <FeaturesSection />
      <RoomScanner />
      <CtaSection />
    </>
  );
}
