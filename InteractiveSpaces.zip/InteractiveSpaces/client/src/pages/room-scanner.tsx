import React from "react";
import RoomScannerComponent from "@/components/room-scanner/room-scanner";
import { Helmet } from "react-helmet";

export default function RoomScanner() {
  return (
    <>
      <Helmet>
        <title>Room Scanner | RoomFit</title>
        <meta name="description" content="Scan your room, upload furniture, and test layouts with our AI-powered room scanner and furniture arrangement tool." />
      </Helmet>
      <div className="pt-8">
        <RoomScannerComponent />
      </div>
    </>
  );
}
