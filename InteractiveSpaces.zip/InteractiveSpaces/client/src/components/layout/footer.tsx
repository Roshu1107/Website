import React from "react";
import { Link } from "wouter";
import { Facebook, Twitter, Instagram } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-neutral-800 text-white">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <span className="text-white font-poppins font-bold text-2xl">RoomFit</span>
            <p className="mt-2 text-neutral-300 text-sm">
              AI-powered room planning and furniture placement to help you design your perfect space.
            </p>
            <div className="mt-6 flex space-x-4">
              <a href="#" className="text-neutral-400 hover:text-white">
                <Facebook className="h-6 w-6" />
                <span className="sr-only">Facebook</span>
              </a>
              <a href="#" className="text-neutral-400 hover:text-white">
                <Twitter className="h-6 w-6" />
                <span className="sr-only">Twitter</span>
              </a>
              <a href="#" className="text-neutral-400 hover:text-white">
                <Instagram className="h-6 w-6" />
                <span className="sr-only">Instagram</span>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-white tracking-wider uppercase">Product</h3>
            <ul className="mt-4 space-y-2">
              <li><a href="#" className="text-neutral-300 hover:text-white text-sm">Features</a></li>
              <li><a href="#" className="text-neutral-300 hover:text-white text-sm">Pricing</a></li>
              <li><a href="#" className="text-neutral-300 hover:text-white text-sm">Case Studies</a></li>
              <li><a href="#" className="text-neutral-300 hover:text-white text-sm">Reviews</a></li>
              <li><a href="#" className="text-neutral-300 hover:text-white text-sm">Updates</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-white tracking-wider uppercase">Support</h3>
            <ul className="mt-4 space-y-2">
              <li><a href="#" className="text-neutral-300 hover:text-white text-sm">Help Center</a></li>
              <li><a href="#" className="text-neutral-300 hover:text-white text-sm">Contact Us</a></li>
              <li><a href="#" className="text-neutral-300 hover:text-white text-sm">Community</a></li>
              <li><a href="#" className="text-neutral-300 hover:text-white text-sm">Developer API</a></li>
              <li><a href="#" className="text-neutral-300 hover:text-white text-sm">Status</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-white tracking-wider uppercase">Company</h3>
            <ul className="mt-4 space-y-2">
              <li><a href="#" className="text-neutral-300 hover:text-white text-sm">About</a></li>
              <li><a href="#" className="text-neutral-300 hover:text-white text-sm">Blog</a></li>
              <li><a href="#" className="text-neutral-300 hover:text-white text-sm">Careers</a></li>
              <li><a href="#" className="text-neutral-300 hover:text-white text-sm">Press</a></li>
              <li><a href="#" className="text-neutral-300 hover:text-white text-sm">Partners</a></li>
            </ul>
          </div>
        </div>
        
        <div className="mt-12 border-t border-neutral-700 pt-8 flex flex-col md:flex-row justify-between">
          <p className="text-base text-neutral-400">&copy; {new Date().getFullYear()} RoomFit, Inc. All rights reserved.</p>
          <div className="mt-4 md:mt-0 flex space-x-6">
            <a href="#" className="text-neutral-400 hover:text-white text-sm">Privacy Policy</a>
            <a href="#" className="text-neutral-400 hover:text-white text-sm">Terms of Service</a>
            <a href="#" className="text-neutral-400 hover:text-white text-sm">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
