import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Menu } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetTrigger
} from "@/components/ui/sheet";

interface NavItem {
  label: string;
  href: string;
}

const navItems: NavItem[] = [
  { label: "Home", href: "/" },
  { label: "Room Scanner", href: "/room-scanner" },
  { label: "How it Works", href: "#how-it-works" },
  { label: "Gallery", href: "#gallery" },
  { label: "About", href: "#about" }
];

export default function Header() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Link href="/">
                <span className="text-primary font-poppins font-bold text-2xl cursor-pointer">
                  RoomFit
                </span>
              </Link>
            </div>
            <nav className="hidden md:ml-10 md:flex space-x-8">
              {navItems.map((item) => (
                <Link 
                  key={item.label} 
                  href={item.href}
                  className={`px-3 py-2 font-medium ${
                    location === item.href
                      ? "text-primary border-b-2 border-primary"
                      : "text-neutral-700 hover:text-primary"
                  }`}
                >
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>
          <div className="flex items-center">
            <Link 
              href="/sign-in"
              className="text-neutral-700 hover:text-primary px-4 py-2 font-medium hidden md:block"
            >
              Sign In
            </Link>
            <Link href="/sign-up">
              <Button className="ml-4 bg-accent hover:bg-accent-dark text-white">
                Sign Up Free
              </Button>
            </Link>

            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="ml-4 md:hidden"
                >
                  <Menu className="h-6 w-6" />
                  <span className="sr-only">Open menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right">
                <div className="flex flex-col space-y-4 mt-8">
                  {navItems.map((item) => (
                    <Link 
                      key={item.label} 
                      href={item.href}
                      onClick={() => setIsOpen(false)}
                      className={`px-3 py-2 font-medium ${
                        location === item.href
                          ? "text-primary"
                          : "text-neutral-700"
                      }`}
                    >
                      {item.label}
                    </Link>
                  ))}
                  <div className="pt-4 mt-4 border-t">
                    <Link href="/sign-in">
                      <Button 
                        variant="outline" 
                        className="w-full mb-3"
                        onClick={() => setIsOpen(false)}
                      >
                        Sign In
                      </Button>
                    </Link>
                    <Link href="/sign-up">
                      <Button 
                        className="w-full bg-accent hover:bg-accent-dark text-white"
                        onClick={() => setIsOpen(false)}
                      >
                        Sign Up Free
                      </Button>
                    </Link>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
