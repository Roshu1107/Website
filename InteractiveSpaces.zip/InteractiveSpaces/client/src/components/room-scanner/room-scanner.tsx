import React, { useState, useEffect } from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Camera, Upload, Layout, Sparkles } from "lucide-react";
import ScanRoomTab from "./scan-room-tab";
import UploadFurnitureTab from "./upload-furniture-tab";
import ArrangeTestTab from "./arrange-test-tab";
import BrowseIdeasTab from "./browse-ideas-tab";
import { RoomData, FurnitureItem } from "@/types";
import { useToast } from "@/hooks/use-toast";

export default function RoomScanner() {
  const [activeTab, setActiveTab] = useState("scan");
  const [roomData, setRoomData] = useState<RoomData | null>(null);
  const [furniture, setFurniture] = useState<FurnitureItem[]>([]);
  const { toast } = useToast();
  
  // Monitor furniture changes to notify user and guide them to next step
  useEffect(() => {
    if (furniture.length > 0 && activeTab === "upload") {
      // Check if any furniture is ready for placement
      const readyFurniture = furniture.filter(item => item.status === 'ready');
      
      if (readyFurniture.length > 0) {
        toast({
          title: "Furniture ready to place",
          description: "Go to the 'Arrange & Test' tab to place your furniture in the room",
        });
      }
    }
  }, [furniture, activeTab]);

  const handleTabChange = (value: string) => {
    if (value === "place" && !roomData) {
      toast({
        title: "Room needed",
        description: "Please scan a room first before arranging furniture",
        variant: "destructive"
      });
      return;
    }
    
    if (value === "place" && furniture.length === 0) {
      toast({
        title: "Furniture needed",
        description: "Please add at least one furniture item before arranging",
        variant: "destructive"
      });
      return;
    }
    
    setActiveTab(value);
  };

  const handleRoomScanned = (data: RoomData) => {
    setRoomData(data);
    // Automatically move to the next tab after room is scanned
    setActiveTab("upload");
    
    toast({
      title: "Room scanned successfully",
      description: "Now upload furniture to place in your room"
    });
  };

  const handleFurnitureAdded = (item: FurnitureItem) => {
    setFurniture((prev) => [...prev, item]);
    
    // If the room is already scanned and this is the first ready furniture item,
    // automatically move to the place tab
    if (roomData && item.status === 'ready') {
      const readyItemsCount = furniture.filter(f => f.status === 'ready').length;
      
      if (readyItemsCount === 0) { // This is the first ready item
        // Allow a small delay for the furniture to be added to the state
        setTimeout(() => {
          setActiveTab("place");
          toast({
            title: "Ready to place",
            description: "Your furniture is ready! You can now arrange it in your room."
          });
        }, 500);
      }
    }
  };

  const handleFurnitureRemoved = (id: string) => {
    setFurniture((prev) => prev.filter(item => item.id !== id));
  };

  return (
    <section id="scanner" className="py-16 gradient-bg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-extrabold text-neutral-900 font-poppins sm:text-4xl">
            Room Scanner & Object Placement
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-neutral-700">
            Scan your room, test furniture placement, and get intelligent recommendations in three easy steps.
          </p>
        </div>

        <Tabs 
          defaultValue="scan" 
          value={activeTab} 
          onValueChange={handleTabChange}
          className="w-full"
        >
          <div className="border-b border-neutral-300">
            <TabsList className="flex justify-center space-x-6 bg-transparent h-auto">
              <TabsTrigger 
                value="scan" 
                className="border-b-2 py-4 px-1 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=inactive]:border-transparent data-[state=inactive]:text-neutral-500 data-[state=inactive]:hover:text-neutral-700 data-[state=inactive]:hover:border-neutral-300 bg-transparent"
              >
                <div className="flex items-center">
                  <Camera className="-ml-0.5 mr-2 h-5 w-5" />
                  <span>Scan Room</span>
                </div>
              </TabsTrigger>
              <TabsTrigger 
                value="upload" 
                className="border-b-2 py-4 px-1 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=inactive]:border-transparent data-[state=inactive]:text-neutral-500 data-[state=inactive]:hover:text-neutral-700 data-[state=inactive]:hover:border-neutral-300 bg-transparent"
              >
                <div className="flex items-center">
                  <Upload className="-ml-0.5 mr-2 h-5 w-5" />
                  <span>Upload Furniture</span>
                </div>
              </TabsTrigger>
              <TabsTrigger 
                value="place" 
                className="border-b-2 py-4 px-1 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=inactive]:border-transparent data-[state=inactive]:text-neutral-500 data-[state=inactive]:hover:text-neutral-700 data-[state=inactive]:hover:border-neutral-300 bg-transparent"
              >
                <div className="flex items-center">
                  <Layout className="-ml-0.5 mr-2 h-5 w-5" />
                  <span>Arrange & Test</span>
                </div>
              </TabsTrigger>
              <TabsTrigger 
                value="ideas" 
                className="border-b-2 py-4 px-1 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=inactive]:border-transparent data-[state=inactive]:text-neutral-500 data-[state=inactive]:hover:text-neutral-700 data-[state=inactive]:hover:border-neutral-300 bg-transparent"
              >
                <div className="flex items-center">
                  <Sparkles className="-ml-0.5 mr-2 h-5 w-5" />
                  <span>Browse Ideas</span>
                </div>
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="scan" className="mt-8">
            <ScanRoomTab onRoomScanned={handleRoomScanned} />
          </TabsContent>
          
          <TabsContent value="upload" className="mt-8">
            <UploadFurnitureTab 
              onFurnitureAdded={handleFurnitureAdded} 
              onFurnitureRemoved={handleFurnitureRemoved}
              furniture={furniture}
            />
          </TabsContent>
          
          <TabsContent value="place" className="mt-8">
            <ArrangeTestTab 
              roomData={roomData}
              furniture={furniture}
            />
          </TabsContent>
          
          <TabsContent value="ideas" className="mt-8">
            <BrowseIdeasTab />
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
}
