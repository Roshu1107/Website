import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Camera, CheckCircle2 } from "lucide-react";
import { CameraFeed } from "@/components/ui/camera-feed";
import { useDepthEstimation } from "@/hooks/use-depth-estimation";
import { RoomData } from "@/types";
import { nanoid } from "nanoid";
import { useToast } from "@/hooks/use-toast";

interface ScanRoomTabProps {
  onRoomScanned: (roomData: RoomData) => void;
}

export default function ScanRoomTab({ onRoomScanned }: ScanRoomTabProps) {
  const [scanning, setScanning] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isProcessingRoom, setIsProcessingRoom] = useState(false);
  const [roomName, setRoomName] = useState("Living Room");
  const [roomScanned, setRoomScanned] = useState(false);
  const { estimateDepth, depthMap, isProcessing, error } = useDepthEstimation();
  const { toast } = useToast();
  
  // Once we have the depth map, we can process the room dimensions
  useEffect(() => {
    if (depthMap && capturedImage && isProcessingRoom) {
      // This would normally use the depth map to calculate actual dimensions
      // For now, we'll simulate that calculation
      
      const roomData: RoomData = {
        id: `room-${nanoid(6)}`,
        name: roomName,
        dimensions: {
          width: "14 ft",
          length: "18 ft",
          height: "9 ft"
        },
        image: capturedImage
      };
      
      // Mark as scanned and call the callback
      setRoomScanned(true);
      setIsProcessingRoom(false);
      setScanning(false);
      
      onRoomScanned(roomData);
      
      toast({
        title: "Room scanned successfully",
        description: "Your room dimensions have been captured",
      });
    }
  }, [depthMap, capturedImage, isProcessingRoom, roomName, onRoomScanned, toast]);
  
  const handleStartScan = async () => {
    setScanning(true);
    setRoomScanned(false);
  };
  
  const handleCapture = (imageData: string) => {
    // Store the captured image
    setCapturedImage(imageData);
    
    // Start processing
    setIsProcessingRoom(true);
    
    // Process the captured image using depth estimation
    estimateDepth(imageData);
  };

  return (
    <div className="lg:grid lg:grid-cols-12 lg:gap-8">
      <div className="lg:col-span-5">
        <h3 className="text-2xl font-bold text-neutral-900 font-poppins">Step 1: Scan Your Room</h3>
        <p className="mt-3 text-neutral-600">
          Use your device's camera to scan the room. Our AI will measure the dimensions and create a digital layout.
        </p>
        
        {roomScanned ? (
          <div className="mt-6 p-4 bg-success/10 border border-success/30 rounded-lg">
            <div className="flex items-center">
              <CheckCircle2 className="h-6 w-6 text-success mr-2" />
              <h4 className="font-medium text-success text-lg">Room Successfully Scanned!</h4>
            </div>
            <p className="mt-2 text-neutral-700">
              Your room has been captured. You can now proceed to the next steps to add furniture and arrange your room.
            </p>
            <div className="mt-4 flex flex-col gap-2">
              <div className="flex justify-between items-center">
                <span className="text-neutral-700 font-medium">Width:</span>
                <span className="text-neutral-900">14 ft</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-neutral-700 font-medium">Length:</span>
                <span className="text-neutral-900">18 ft</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-neutral-700 font-medium">Height:</span>
                <span className="text-neutral-900">9 ft</span>
              </div>
            </div>
          </div>
        ) : (
          <>
            <ul className="mt-8 space-y-5">
              <li className="flex items-start">
                <div className="flex-shrink-0">
                  <svg className="h-5 w-5 text-success" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                </div>
                <p className="ml-3 text-neutral-600">
                  <span className="font-medium text-neutral-800">Move around the room</span> - capture all angles for better accuracy
                </p>
              </li>
              <li className="flex items-start">
                <div className="flex-shrink-0">
                  <svg className="h-5 w-5 text-success" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                </div>
                <p className="ml-3 text-neutral-600">
                  <span className="font-medium text-neutral-800">Ensure good lighting</span> - helps with accurate detection
                </p>
              </li>
              <li className="flex items-start">
                <div className="flex-shrink-0">
                  <svg className="h-5 w-5 text-success" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                </div>
                <p className="ml-3 text-neutral-600">
                  <span className="font-medium text-neutral-800">Stay still</span> - when measuring specific areas for better precision
                </p>
              </li>
            </ul>
            <div className="mt-8">
              <Button 
                onClick={handleStartScan}
                disabled={scanning || isProcessing}
                className="inline-flex items-center px-6 py-3 shadow-sm text-white bg-primary hover:bg-primary-dark"
              >
                <Camera className="mr-2 h-5 w-5" />
                {scanning ? "Scanning..." : isProcessingRoom ? "Processing..." : "Start Room Scan"}
              </Button>
            </div>
          </>
        )}
        
        {isProcessingRoom && (
          <div className="mt-4 p-4 bg-primary/10 border border-primary/30 rounded-lg">
            <div className="flex items-center">
              <div className="animate-spin mr-2">
                <svg className="h-5 w-5 text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              </div>
              <p className="text-primary font-medium">Processing room data...</p>
            </div>
          </div>
        )}
      </div>
      <div className="mt-12 lg:mt-0 lg:col-span-7">
        <CameraFeed 
          scanning={scanning} 
          onCapture={handleCapture}
        />
      </div>
    </div>
  );
}
