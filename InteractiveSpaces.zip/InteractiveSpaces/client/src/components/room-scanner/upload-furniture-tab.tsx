import React, { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Camera, Plus, Upload } from "lucide-react";
import { ObjectCard } from "@/components/ui/object-card";
import { FurnitureItem } from "@/types";
import { nanoid } from "nanoid";
import { useToast } from "@/hooks/use-toast";

interface UploadFurnitureTabProps {
  onFurnitureAdded: (item: FurnitureItem) => void;
  onFurnitureRemoved: (id: string) => void;
  furniture: FurnitureItem[];
}

export default function UploadFurnitureTab({ 
  onFurnitureAdded, 
  onFurnitureRemoved,
  furniture 
}: UploadFurnitureTabProps) {
  const [processingItem, setProcessingItem] = useState<FurnitureItem | null>(null);
  const [manualName, setManualName] = useState("");
  const [width, setWidth] = useState("");
  const [height, setHeight] = useState("");
  const [depth, setDepth] = useState("");
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Check file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please upload an image under 10MB",
        variant: "destructive"
      });
      return;
    }
    
    // Process the file
    const reader = new FileReader();
    reader.onload = (event) => {
      if (typeof event.target?.result === "string") {
        // Create a processing placeholder while the image is being analyzed
        const tempItem: FurnitureItem = {
          id: nanoid(),
          name: file.name.split('.')[0],
          dimensions: "Processing...",
          image: event.target.result,
          status: "processing"
        };
        
        setProcessingItem(tempItem);
        
        // Simulate processing delay
        setTimeout(() => {
          const processedItem: FurnitureItem = {
            ...tempItem,
            dimensions: `28" × 30" × 33"`,
            status: "ready"
          };
          
          setProcessingItem(null);
          onFurnitureAdded(processedItem);
        }, 3000);
      }
    };
    
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    
    const file = e.dataTransfer.files?.[0];
    if (!file) return;
    
    // Check if it's an image
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid file type",
        description: "Please upload an image file (PNG, JPG, GIF)",
        variant: "destructive"
      });
      return;
    }
    
    // Process the file (reusing logic)
    const reader = new FileReader();
    reader.onload = (event) => {
      if (typeof event.target?.result === "string") {
        const tempItem: FurnitureItem = {
          id: nanoid(),
          name: file.name.split('.')[0],
          dimensions: "Processing...",
          image: event.target.result,
          status: "processing"
        };
        
        setProcessingItem(tempItem);
        
        setTimeout(() => {
          const processedItem: FurnitureItem = {
            ...tempItem,
            dimensions: `24" × 36" × 18"`,
            status: "ready"
          };
          
          setProcessingItem(null);
          onFurnitureAdded(processedItem);
        }, 3000);
      }
    };
    
    reader.readAsDataURL(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleManualAdd = () => {
    if (!manualName || !width || !height || !depth) {
      toast({
        title: "Missing information",
        description: "Please fill in all dimension fields",
        variant: "destructive"
      });
      return;
    }
    
    const newItem: FurnitureItem = {
      id: nanoid(),
      name: manualName,
      dimensions: `${width}" × ${depth}" × ${height}"`,
      image: "https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      status: "ready"
    };
    
    onFurnitureAdded(newItem);
    
    // Reset form
    setManualName("");
    setWidth("");
    setHeight("");
    setDepth("");
    
    toast({
      title: "Furniture added",
      description: "Furniture item has been added successfully"
    });
  };

  const handleOpenCamera = () => {
    // This would open the device camera
    toast({
      title: "Camera opened",
      description: "Camera functionality would open here"
    });
  };

  return (
    <div className="lg:grid lg:grid-cols-12 lg:gap-8">
      <div className="lg:col-span-5">
        <h3 className="text-2xl font-bold text-neutral-900 font-poppins">Step 2: Upload Furniture</h3>
        <p className="mt-3 text-neutral-600">
          Take a photo of the furniture you want to place, or upload an existing image. Our AI will automatically estimate its dimensions.
        </p>
        <div className="mt-8 space-y-4">
          <div 
            className="relative border-2 border-dashed border-neutral-300 rounded-lg p-6 flex flex-col justify-center items-center cursor-pointer hover:border-primary"
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onClick={() => fileInputRef.current?.click()}
          >
            <Upload className="h-12 w-12 text-neutral-400" />
            <span className="mt-2 block text-sm font-medium text-neutral-700">
              Drop files or click to upload
            </span>
            <span className="mt-1 block text-xs text-neutral-500">
              PNG, JPG, GIF up to 10MB
            </span>
            <input 
              type="file" 
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
            />
          </div>
          
          <div>
            <p className="text-sm font-medium text-neutral-700 mb-2">Or take a photo with your camera</p>
            <Button 
              className="w-full text-white bg-primary hover:bg-primary-dark"
              onClick={handleOpenCamera}
            >
              <Camera className="mr-2 h-5 w-5" />
              Open Camera
            </Button>
          </div>

          <div className="p-4 bg-white rounded-lg shadow-md">
            <h4 className="font-medium text-neutral-900">Manual measurements</h4>
            <p className="text-sm text-neutral-600 mb-4">If you know the dimensions, enter them manually:</p>
            <div className="space-y-4">
              <div>
                <Label htmlFor="itemName">Item name</Label>
                <Input 
                  id="itemName" 
                  value={manualName}
                  onChange={(e) => setManualName(e.target.value)}
                  placeholder="Sofa, Chair, Table..."
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="width">Width</Label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <Input 
                      id="width"
                      value={width}
                      onChange={(e) => setWidth(e.target.value.replace(/[^0-9.]/g, ''))}
                      placeholder="0.00"
                      className="pr-12"
                    />
                    <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                      <span className="text-neutral-500 sm:text-sm">inches</span>
                    </div>
                  </div>
                </div>
                <div>
                  <Label htmlFor="height">Height</Label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <Input 
                      id="height"
                      value={height}
                      onChange={(e) => setHeight(e.target.value.replace(/[^0-9.]/g, ''))}
                      placeholder="0.00"
                      className="pr-12"
                    />
                    <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                      <span className="text-neutral-500 sm:text-sm">inches</span>
                    </div>
                  </div>
                </div>
                <div>
                  <Label htmlFor="depth">Depth</Label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <Input 
                      id="depth"
                      value={depth}
                      onChange={(e) => setDepth(e.target.value.replace(/[^0-9.]/g, ''))}
                      placeholder="0.00"
                      className="pr-12"
                    />
                    <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                      <span className="text-neutral-500 sm:text-sm">inches</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-end">
                  <Button 
                    className="w-full text-white bg-secondary hover:bg-secondary-dark"
                    onClick={handleManualAdd}
                  >
                    Save
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="mt-12 lg:mt-0 lg:col-span-7">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="p-4">
            <div className="mb-4 flex justify-between items-center">
              <h4 className="font-medium text-lg text-neutral-900">Added Furniture Items</h4>
              {furniture.length > 0 && (
                <Button variant="link" className="text-sm text-primary hover:text-primary-dark p-0">
                  View all
                </Button>
              )}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {furniture.map((item) => (
                <ObjectCard 
                  key={item.id} 
                  item={item}
                  onRemove={onFurnitureRemoved}
                />
              ))}
              
              {processingItem && (
                <ObjectCard 
                  item={processingItem} 
                  processing={true}
                />
              )}

              {/* Add new item button */}
              <Button
                variant="outline"
                className="h-full border-2 border-dashed border-neutral-300 hover:border-primary transition flex flex-col items-center justify-center py-12"
                onClick={() => fileInputRef.current?.click()}
              >
                <Plus className="h-12 w-12 text-neutral-400 group-hover:text-primary mb-2" />
                <span className="text-sm font-medium text-neutral-700 group-hover:text-primary">Add New Item</span>
              </Button>
            </div>
            
            {furniture.length === 0 && !processingItem && (
              <div className="text-center py-12 text-neutral-500">
                <Upload className="mx-auto h-12 w-12 text-neutral-300 mb-2" />
                <p>No furniture items added yet</p>
                <p className="text-sm mt-1">Upload or manually add furniture to get started</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
