import React, { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { DragObject } from "@/components/ui/drag-object";
import { RoomDimensions } from "@/components/ui/room-dimension";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardFooter 
} from "@/components/ui/card";
import { RoomData, FurnitureItem, AISuggestion } from "@/types";
import { RefreshCw, Plus, Minus, MousePointer } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ArrangeTestTabProps {
  roomData: RoomData | null;
  furniture: FurnitureItem[];
}

export default function ArrangeTestTab({ roomData, furniture }: ArrangeTestTabProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  
  // Calculate a position for any new furniture items
  const calculatePositionForNewItem = (index: number) => {
    // Create a grid-like placement starting from the top left
    const itemsPerRow = 3;
    const xPos = 80 + (index % itemsPerRow) * 150;
    const yPos = 80 + Math.floor(index / itemsPerRow) * 150;
    return { x: xPos, y: yPos };
  };
  
  // Generate the placedFurniture array from the furniture prop
  const [placedFurniture, setPlacedFurniture] = useState<
    Array<FurnitureItem & { position: { x: number, y: number }, fits: boolean }>
  >([]);
  
  // Update the placedFurniture when the furniture prop changes
  useEffect(() => {
    // Filter for ready furniture
    const readyFurniture = furniture.filter(item => item.status === 'ready');
    
    setPlacedFurniture(
      readyFurniture.map((item, index) => {
        const existingItem = placedFurniture.find(f => f.id === item.id);
        
        return {
          ...item,
          position: existingItem?.position || calculatePositionForNewItem(index),
          fits: Math.random() > 0.3 // Simple random fitting for demo - in a real app this would be calculated
        };
      })
    );
  }, [furniture]);

  // AI suggestions based on furniture placement
  const [suggestions, setSuggestions] = useState<AISuggestion[]>([
    {
      id: "suggestion-1",
      furnitureId: "coffee-table-1",
      type: "warning",
      message: "This table is too large for this space and blocks the natural walkway.",
      alternatives: [
        {
          id: "alt-1",
          name: "Round Coffee Table",
          dimensions: "36\" diameter × 18\" height",
          image: "https://pixabay.com/get/g60e3bcac3209f3e09cd6e5f649b20e93aa41ec2a8b642d731bfaf9194221b3647c449b90c7e45987d0624b73e7d1d4c7a2bce514fa4253c9e9b3e5057cd63533_1280.jpg"
        },
        {
          id: "alt-2",
          name: "Nesting Tables Set",
          dimensions: "Various sizes, space-saving",
          image: "https://images.unsplash.com/photo-1594026112284-02bb6f3352fe?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80"
        }
      ]
    },
    {
      id: "suggestion-2",
      furnitureId: "armchair-1",
      type: "success",
      message: "Great fit! The armchair size works well in this corner.",
      placementTip: "Try angling it slightly toward the center of the room for better conversation flow."
    }
  ]);

  // General recommendations for the room
  const [roomRecommendations, setRoomRecommendations] = useState([
    "Consider adding a small side table between the armchair and sofa.",
    "The north wall has good space for a TV console or bookshelf.",
    "Add a rug (5'×7') to define the seating area and add warmth."
  ]);

  const handlePositionChange = (id: string, position: { x: number; y: number }) => {
    setPlacedFurniture(prev => 
      prev.map(item => item.id === id ? { ...item, position } : item)
    );
  };

  const handleReset = () => {
    setPlacedFurniture(prev => 
      prev.map(item => ({ ...item, position: { x: Math.random() * 200, y: Math.random() * 100 } }))
    );
    
    toast({
      title: "Layout reset",
      description: "Room layout has been reset"
    });
  };

  const handleSaveLayout = () => {
    toast({
      title: "Layout saved",
      description: "Your room layout has been saved successfully"
    });
  };

  if (!roomData) {
    return (
      <div className="text-center py-12">
        <p className="text-neutral-500">Please scan a room first</p>
        <p className="text-sm mt-1">Go to the "Scan Room" tab to get started</p>
      </div>
    );
  }

  return (
    <div className="lg:grid lg:grid-cols-12 lg:gap-8">
      <div className="lg:col-span-8">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="p-4 bg-neutral-800 text-white flex justify-between items-center">
            <h3 className="font-medium">Room Layout: {roomData.name}</h3>
            <div className="flex space-x-3">
              <Button 
                variant="secondary" 
                size="sm" 
                className="bg-neutral-700 hover:bg-neutral-600 text-white"
                onClick={handleReset}
              >
                Reset
              </Button>
              <Button 
                size="sm" 
                className="bg-primary hover:bg-primary-dark text-white"
                onClick={handleSaveLayout}
              >
                Save Layout
              </Button>
            </div>
          </div>
          
          <div 
            className="relative bg-cover bg-center" 
            style={{ 
              height: 500, 
              backgroundImage: `url(${roomData.image})` 
            }}
            ref={containerRef}
          >
            {/* Room dimensions */}
            <RoomDimensions
              width={roomData.dimensions.width}
              height={roomData.dimensions.length}
            />
            
            {/* Placed furniture items */}
            {placedFurniture.map((item) => (
              <DragObject
                key={item.id}
                item={item}
                fits={item.fits}
                initialPosition={item.position}
                onPositionChange={handlePositionChange}
                containerRef={containerRef}
              />
            ))}
            
            {/* Controls overlay */}
            <div className="absolute bottom-4 right-4 bg-white rounded-lg shadow-md p-3">
              <div className="flex items-center space-x-4">
                <Button 
                  variant="outline" 
                  size="icon" 
                  className="p-2 bg-neutral-200 hover:bg-neutral-300"
                >
                  <Plus className="h-5 w-5" />
                </Button>
                <Button 
                  variant="outline" 
                  size="icon" 
                  className="p-2 bg-neutral-200 hover:bg-neutral-300"
                >
                  <Minus className="h-5 w-5" />
                </Button>
                <Button 
                  variant="outline" 
                  size="icon" 
                  className="p-2 bg-neutral-200 hover:bg-neutral-300"
                >
                  <MousePointer className="h-5 w-5" />
                </Button>
                <Button 
                  variant="outline" 
                  size="icon" 
                  className="p-2 bg-neutral-200 hover:bg-neutral-300"
                >
                  <RefreshCw className="h-5 w-5" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="mt-8 lg:mt-0 lg:col-span-4">
        <Card>
          <CardHeader className="pb-3 border-b border-neutral-200">
            <CardTitle>AI Suggestions</CardTitle>
          </CardHeader>
          <CardContent className="p-4">
            {suggestions.map((suggestion) => {
              const item = placedFurniture.find(f => f.id === suggestion.furnitureId);
              
              if (!item) return null;
              
              return (
                <div key={suggestion.id} className="mb-6">
                  <h4 className="text-neutral-700 font-medium mb-2">{item.name}</h4>
                  <div className={`p-3 bg-${suggestion.type === 'warning' ? 'error' : suggestion.type === 'success' ? 'success' : 'primary'} bg-opacity-10 border-l-4 border-${suggestion.type === 'warning' ? 'error' : suggestion.type === 'success' ? 'success' : 'primary'} rounded`}>
                    <div className="flex">
                      <div className="flex-shrink-0">
                        <svg className={`h-5 w-5 text-${suggestion.type === 'warning' ? 'error' : suggestion.type === 'success' ? 'success' : 'primary'}`} fill="currentColor" viewBox="0 0 20 20">
                          {suggestion.type === 'warning' ? (
                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                          ) : (
                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                          )}
                        </svg>
                      </div>
                      <div className="ml-3">
                        <p className={`text-sm text-${suggestion.type === 'warning' ? 'error' : suggestion.type === 'success' ? 'success' : 'primary'}`}>
                          {suggestion.message}
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  {suggestion.alternatives && (
                    <div className="mt-3">
                      <h5 className="text-sm font-medium text-neutral-700">Suggested alternatives:</h5>
                      <ul className="mt-2 space-y-2">
                        {suggestion.alternatives.map((alt) => (
                          <li key={alt.id} className="flex items-center p-2 hover:bg-neutral-50 rounded cursor-pointer">
                            <img src={alt.image} alt={alt.name} className="w-10 h-10 object-cover rounded" />
                            <div className="ml-3">
                              <p className="text-sm font-medium text-neutral-900">{alt.name}</p>
                              <p className="text-xs text-neutral-500">{alt.dimensions}</p>
                            </div>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  {suggestion.placementTip && (
                    <div className="mt-3">
                      <h5 className="text-sm font-medium text-neutral-700">Suggested placement:</h5>
                      <p className="text-sm text-neutral-600 mt-1">
                        {suggestion.placementTip}
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
            
            <div>
              <h4 className="text-neutral-700 font-medium mb-2">Room Recommendations</h4>
              <ul className="space-y-3">
                {roomRecommendations.map((rec, index) => (
                  <li key={index} className="flex">
                    <div className="flex-shrink-0">
                      <svg className="h-5 w-5 text-primary" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                        <path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <p className="ml-3 text-sm text-neutral-600">
                      {rec}
                    </p>
                  </li>
                ))}
              </ul>
            </div>
          </CardContent>
          <CardFooter className="bg-neutral-50 p-4 border-t border-neutral-200">
            <Button className="w-full bg-secondary hover:bg-secondary-dark text-white">
              View All Suggestions
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
