import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { 
  Heart, 
  LayoutGrid, 
  ChevronRight, 
  Plus,
  ArrowRight,
  PlusCircle
} from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface RoomIdea {
  id: string;
  name: string;
  description: string;
  image: string;
  style: string;
  size: string;
  furniture: {
    name: string;
    dimensions: string;
    image: string;
  }[];
}

const ROOM_IDEAS: Record<string, RoomIdea[]> = {
  "living-room": [
    {
      id: "living-room-1",
      name: "Modern Minimalist Living Room",
      description: "Clean lines and neutral colors create a calming space",
      image: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&h=800&q=80",
      style: "Modern",
      size: "Medium (15' x 18')",
      furniture: [
        {
          name: "Minimalist Sofa",
          dimensions: "84\" × 36\" × 32\"",
          image: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        },
        {
          name: "Glass Coffee Table",
          dimensions: "36\" × 36\" × 18\"",
          image: "https://images.unsplash.com/photo-1533090481720-856c6e3c1fdc?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        },
        {
          name: "Floor Lamp",
          dimensions: "12\" × 12\" × 68\"",
          image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        }
      ]
    },
    {
      id: "living-room-2",
      name: "Cozy Rustic Farmhouse",
      description: "Warm tones and natural materials for a homey feel",
      image: "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&h=800&q=80",
      style: "Rustic",
      size: "Large (20' x 22')",
      furniture: [
        {
          name: "Plush Sectional Sofa",
          dimensions: "120\" × 84\" × 36\"",
          image: "https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        },
        {
          name: "Reclaimed Wood Coffee Table",
          dimensions: "48\" × 28\" × 18\"",
          image: "https://images.unsplash.com/photo-1604061896917-acc913e69a18?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        },
        {
          name: "Rustic Side Table",
          dimensions: "22\" × 22\" × 24\"",
          image: "https://images.unsplash.com/photo-1551907234-fb773fb08a2a?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        }
      ]
    }
  ],
  "bedroom": [
    {
      id: "bedroom-1",
      name: "Serene Scandinavian Bedroom",
      description: "Light, airy design with natural textures",
      image: "https://images.unsplash.com/photo-1616594039964-ae9021a400a0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&h=800&q=80",
      style: "Scandinavian",
      size: "Medium (12' x 14')",
      furniture: [
        {
          name: "Platform Bed Frame",
          dimensions: "80\" × 60\" × 14\"",
          image: "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        },
        {
          name: "Minimalist Dresser",
          dimensions: "60\" × 18\" × 30\"",
          image: "https://images.unsplash.com/photo-1551562149-191f68edc37b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        },
        {
          name: "Floating Bedside Tables",
          dimensions: "16\" × 13\" × 6\"",
          image: "https://images.unsplash.com/photo-1503602642458-232111445657?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        }
      ]
    },
    {
      id: "bedroom-2",
      name: "Luxurious Contemporary Suite",
      description: "Sophisticated design with premium materials",
      image: "https://images.unsplash.com/photo-1540518614846-7eded433c457?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&h=800&q=80",
      style: "Contemporary",
      size: "Large (16' x 18')",
      furniture: [
        {
          name: "King Upholstered Bed",
          dimensions: "84\" × 76\" × 58\"",
          image: "https://images.unsplash.com/photo-1588046130717-0eb0c9a3ba15?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        },
        {
          name: "Modern Nightstands (Set of 2)",
          dimensions: "24\" × 16\" × 27\"",
          image: "https://images.unsplash.com/photo-1551298698-66b830a4f11c?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        },
        {
          name: "Accent Chair",
          dimensions: "32\" × 28\" × 34\"",
          image: "https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        }
      ]
    }
  ],
  "kitchen": [
    {
      id: "kitchen-1",
      name: "Modern Open Concept Kitchen",
      description: "Sleek design with integrated appliances",
      image: "https://images.unsplash.com/photo-1556911220-e15b29be8c8f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&h=800&q=80",
      style: "Modern",
      size: "Medium (12' x 16')",
      furniture: [
        {
          name: "Kitchen Island",
          dimensions: "72\" × 42\" × 36\"",
          image: "https://images.unsplash.com/photo-1560185127-6ed189bf02f4?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        },
        {
          name: "Bar Stools (Set of 3)",
          dimensions: "18\" × 18\" × 30\"",
          image: "https://images.unsplash.com/photo-1561677978-502b20fa9b4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        },
        {
          name: "Pendant Lights (Set of 2)",
          dimensions: "12\" × 12\" × 14\"",
          image: "https://images.unsplash.com/photo-1573146500785-c8f4193bb162?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        }
      ]
    }
  ],
  "bathroom": [
    {
      id: "bathroom-1",
      name: "Spa-Like Master Bathroom",
      description: "Luxurious retreat with natural elements",
      image: "https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&h=800&q=80",
      style: "Contemporary",
      size: "Medium (8' x 12')",
      furniture: [
        {
          name: "Freestanding Bathtub",
          dimensions: "67\" × 32\" × 23\"",
          image: "https://images.unsplash.com/photo-1575245136525-06c7388e5cc0?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        },
        {
          name: "Double Vanity",
          dimensions: "60\" × 22\" × 34\"",
          image: "https://images.unsplash.com/photo-1585412727339-54e4bae3bbf9?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        },
        {
          name: "Storage Cabinet",
          dimensions: "24\" × 18\" × 72\"",
          image: "https://images.unsplash.com/photo-1594731804699-1315fbdcfe6e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        }
      ]
    }
  ]
};

export default function BrowseIdeasTab() {
  const { toast } = useToast();
  const [activeCategory, setActiveCategory] = useState("living-room");
  const [selectedIdea, setSelectedIdea] = useState<RoomIdea | null>(null);
  
  const handleAddLayout = (idea: RoomIdea) => {
    setSelectedIdea(idea);
    toast({
      title: "Layout saved",
      description: `Added "${idea.name}" to your layouts`
    });
  };
  
  const handleAddFurniture = (furniture: {name: string, dimensions: string, image: string}) => {
    toast({
      title: "Furniture added",
      description: `Added "${furniture.name}" to your furniture items`
    });
  };
  
  return (
    <div className="py-4">
      <div className="mb-10">
        <h3 className="text-2xl font-bold text-neutral-900 font-poppins mb-2">Browse Room Ideas</h3>
        <p className="text-neutral-600">
          Explore professionally designed rooms and find inspiration for your own space.
          Click on a room to see details and furniture.
        </p>
      </div>
      
      <Tabs 
        defaultValue="living-room"
        value={activeCategory}
        onValueChange={setActiveCategory}
        className="w-full"
      >
        <TabsList className="flex mb-8 p-1 bg-neutral-100 rounded-lg">
          <TabsTrigger 
            value="living-room" 
            className="flex-1 rounded-md py-3 data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=inactive]:hover:bg-neutral-200/50"
          >
            Living Room
          </TabsTrigger>
          <TabsTrigger 
            value="bedroom" 
            className="flex-1 rounded-md py-3 data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=inactive]:hover:bg-neutral-200/50"
          >
            Bedroom
          </TabsTrigger>
          <TabsTrigger 
            value="kitchen" 
            className="flex-1 rounded-md py-3 data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=inactive]:hover:bg-neutral-200/50"
          >
            Kitchen
          </TabsTrigger>
          <TabsTrigger 
            value="bathroom" 
            className="flex-1 rounded-md py-3 data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=inactive]:hover:bg-neutral-200/50"
          >
            Bathroom
          </TabsTrigger>
        </TabsList>
        
        {Object.entries(ROOM_IDEAS).map(([category, ideas]) => (
          <TabsContent key={category} value={category} className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {ideas.map((idea) => (
                <Card key={idea.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <div className="relative h-64 overflow-hidden">
                    <img 
                      src={idea.image} 
                      alt={idea.name} 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-4 right-4 flex gap-2">
                      <Badge className="bg-white/80 text-neutral-800 hover:bg-white">
                        {idea.style}
                      </Badge>
                      <Badge className="bg-white/80 text-neutral-800 hover:bg-white">
                        {idea.size}
                      </Badge>
                    </div>
                  </div>
                  
                  <CardHeader className="pb-2">
                    <CardTitle className="text-xl">{idea.name}</CardTitle>
                  </CardHeader>
                  
                  <CardContent className="pb-4">
                    <p className="text-neutral-600 mb-4">{idea.description}</p>
                    
                    <div>
                      <h4 className="text-sm font-medium text-neutral-900 mb-3">Furniture Included:</h4>
                      <ul className="space-y-3">
                        {idea.furniture.slice(0, 3).map((item, index) => (
                          <li key={index} className="flex items-center justify-between">
                            <div className="flex items-center">
                              <div className="w-12 h-12 rounded overflow-hidden mr-3">
                                <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                              </div>
                              <div>
                                <p className="text-sm font-medium">{item.name}</p>
                                <p className="text-xs text-neutral-500">{item.dimensions}</p>
                              </div>
                            </div>
                            <Button 
                              variant="outline" 
                              size="sm"
                              className="h-8 px-2 text-xs"
                              onClick={() => handleAddFurniture(item)}
                            >
                              <PlusCircle className="h-3.5 w-3.5 mr-1" />
                              Add
                            </Button>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                  
                  <CardFooter className="pt-2 border-t border-neutral-100 flex justify-between">
                    <Button variant="ghost" size="sm" className="text-primary">
                      View Details <ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                    <Button 
                      variant="default" 
                      size="sm"
                      className="bg-secondary hover:bg-secondary-dark text-white"
                      onClick={() => handleAddLayout(idea)}
                    >
                      <LayoutGrid className="h-4 w-4 mr-2" />
                      Add This Layout
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}