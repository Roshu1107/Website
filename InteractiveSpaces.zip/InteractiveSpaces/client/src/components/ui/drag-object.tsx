import React, { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { FurnitureItem } from "@/types";

interface DragObjectProps {
  item: FurnitureItem;
  fits: boolean;
  initialPosition: { x: number; y: number };
  initialRotation?: number;
  onPositionChange?: (id: string, position: { x: number; y: number }) => void;
  containerRef: React.RefObject<HTMLDivElement>;
}

export function DragObject({
  item,
  fits,
  initialPosition,
  initialRotation = 0,
  onPositionChange,
  containerRef
}: DragObjectProps) {
  const [rotation, setRotation] = useState(initialRotation);
  const itemRef = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState(initialPosition);
  const [constraintBox, setConstraintBox] = useState({ left: 0, top: 0, right: 0, bottom: 0 });

  // Update constraint box when container changes
  useEffect(() => {
    if (containerRef.current && itemRef.current) {
      const containerRect = containerRef.current.getBoundingClientRect();
      const itemRect = itemRef.current.getBoundingClientRect();
      
      setConstraintBox({
        left: 0,
        top: 0,
        right: containerRect.width - itemRect.width,
        bottom: containerRect.height - itemRect.height
      });
    }
  }, [containerRef, item]);

  // Convert size string to dimensions
  const getDimensions = () => {
    const [width, depth, height] = item.dimensions
      .replace(/['"]/g, '')
      .split('×')
      .map(dim => parseInt(dim.trim()));
    
    // Scale down by factor of 6 for display
    const scaleFactor = 6;
    return {
      width: width ? width / scaleFactor : 50,
      height: height ? height / scaleFactor : 50
    };
  };

  const dimensions = getDimensions();

  const handleDragEnd = (_, info) => {
    const newPosition = { x: info.point.x, y: info.point.y };
    setPosition(newPosition);
    
    if (onPositionChange) {
      onPositionChange(item.id, newPosition);
    }
  };

  const rotateItem = () => {
    const newRotation = rotation + 15;
    setRotation(newRotation);
  };

  return (
    <motion.div
      ref={itemRef}
      className={`object-placeholder ${fits ? 'object-fit' : 'object-no-fit'}`}
      style={{
        width: `${dimensions.width}px`,
        height: `${dimensions.height}px`,
        left: position.x,
        top: position.y,
        rotate: `${rotation}deg`
      }}
      drag
      dragMomentum={false}
      initial={false}
      animate={{ 
        rotate: rotation
      }}
      dragConstraints={constraintBox}
      onDragEnd={handleDragEnd}
      whileDrag={{ scale: 1.05 }}
    >
      <div className="flex flex-col items-center justify-center w-full h-full p-1">
        <span className="text-xs truncate max-w-full">{item.name}</span>
        <button 
          className="absolute -top-3 -right-3 bg-white rounded-full p-1 shadow-md"
          onClick={rotateItem}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
        </button>
      </div>
    </motion.div>
  );
}
