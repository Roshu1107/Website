import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MoreVertical } from "lucide-react";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { FurnitureItem } from "@/types";

interface ObjectCardProps {
  item: FurnitureItem;
  onSelect?: (item: FurnitureItem) => void;
  processing?: boolean;
  onRemove?: (id: string) => void;
  onEdit?: (id: string) => void;
}

export function ObjectCard({ 
  item, 
  onSelect, 
  processing = false,
  onRemove,
  onEdit
}: ObjectCardProps) {
  const { id, name, dimensions, image, status } = item;
  
  const getStatusBadge = () => {
    if (processing) {
      return (
        <Badge variant="outline" className="bg-neutral-200 text-neutral-700">
          Analyzing
        </Badge>
      );
    }
    
    switch (status) {
      case 'ready':
        return (
          <Badge variant="outline" className="bg-success bg-opacity-10 text-success">
            Ready to place
          </Badge>
        );
      case 'error':
        return (
          <Badge variant="outline" className="bg-error bg-opacity-10 text-error">
            Error
          </Badge>
        );
      default:
        return (
          <Badge variant="outline" className="bg-neutral-200 text-neutral-700">
            Processing
          </Badge>
        );
    }
  };
  
  const handleClick = () => {
    if (!processing && onSelect) {
      onSelect(item);
    }
  };
  
  return (
    <Card 
      className={`group relative bg-neutral-100 hover:shadow-md transition ${processing ? 'cursor-default' : 'cursor-pointer'}`}
      onClick={handleClick}
    >
      <CardContent className="p-3">
        <div className="w-full overflow-hidden rounded-lg bg-neutral-200 h-48">
          {processing ? (
            <div className="w-full h-full flex items-center justify-center">
              <div className="loading-animation">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
              </div>
            </div>
          ) : (
            <img 
              src={image} 
              alt={name} 
              className="w-full h-full object-cover" 
            />
          )}
        </div>
        <div className="mt-3">
          <h3 className="text-base font-medium text-neutral-900">{name}</h3>
          <p className="text-sm text-neutral-500">
            {processing ? "Processing image..." : dimensions}
          </p>
          <div className="mt-2 flex justify-between items-center">
            {getStatusBadge()}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="text-primary hover:text-primary-dark"
                  onClick={(e) => e.stopPropagation()}
                >
                  <MoreVertical className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {!processing && (
                  <>
                    <DropdownMenuItem onClick={() => onEdit && onEdit(id)}>
                      Edit dimensions
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => onRemove && onRemove(id)}>
                      Remove
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
