import React, { useRef, useEffect, useState } from "react";
import { useCameraFeed } from "@/hooks/use-camera";
import { Button } from "@/components/ui/button";
import { Camera, Video, Copy, Check, RefreshCw } from "lucide-react";

interface CameraFeedProps {
  scanning?: boolean;
  onCapture?: (imageData: string) => void;
  className?: string;
}

export function CameraFeed({ 
  scanning = false, 
  onCapture, 
  className 
}: CameraFeedProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { stream, error, startCamera, stopCamera } = useCameraFeed();
  const [roomInfo, setRoomInfo] = useState<string | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [captureFeedback, setCaptureFeedback] = useState(false);

  useEffect(() => {
    if (stream && videoRef.current) {
      videoRef.current.srcObject = stream;
    }

    // Set mock room info after 3 seconds of scanning
    if (scanning) {
      const timer = setTimeout(() => {
        setRoomInfo("Living Room, 18' x 14'");
      }, 3000);
      
      return () => clearTimeout(timer);
    }

    return () => {
      if (stream) {
        stopCamera();
      }
    };
  }, [stream, scanning, stopCamera]);

  const handleCapture = () => {
    if (!videoRef.current || !canvasRef.current) return;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    // Get the image data as a base64 string
    const imageData = canvas.toDataURL("image/png");
    
    // Store the image in component state
    setCapturedImage(imageData);
    
    // Show visual feedback that the image was captured
    setCaptureFeedback(true);
    setTimeout(() => setCaptureFeedback(false), 1500);
    
    // Pass it to the parent component
    if (onCapture) {
      onCapture(imageData);
    }
  };
  
  const resetCapture = () => {
    setCapturedImage(null);
  };

  const handleStartCamera = async () => {
    await startCamera();
  };

  return (
    <div className={`relative bg-white rounded-lg shadow-lg overflow-hidden ${className}`}>
      <div className={`camera-feed ${scanning ? 'scan-animation' : ''}`}>
        {error ? (
          <div className="w-full h-full flex flex-col items-center justify-center text-white text-center p-6 bg-black bg-opacity-80">
            <p className="text-red-500 mb-2">Error accessing camera</p>
            <p className="text-sm">{error}</p>
            <Button 
              variant="secondary" 
              className="mt-4"
              onClick={handleStartCamera}
            >
              Try Again
            </Button>
          </div>
        ) : capturedImage ? (
          <div className="relative">
            <img 
              src={capturedImage} 
              alt="Captured room" 
              className="w-full h-full object-cover" 
            />
            <div className="absolute top-0 right-0 m-4">
              <Button 
                variant="outline" 
                size="sm"
                className="bg-white/80 hover:bg-white"
                onClick={resetCapture}
              >
                <RefreshCw className="mr-2 h-4 w-4" />
                Rescan
              </Button>
            </div>
            {captureFeedback && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                <div className="bg-success text-white rounded-full p-4">
                  <Check className="h-8 w-8" />
                </div>
              </div>
            )}
          </div>
        ) : stream ? (
          <video 
            ref={videoRef} 
            className="w-full h-full object-cover" 
            autoPlay 
            playsInline
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center text-center p-6 bg-black bg-opacity-80">
            <Button 
              variant="secondary" 
              className="mb-4"
              onClick={handleStartCamera}
            >
              <Camera className="mr-2 h-5 w-5" />
              Start Camera
            </Button>
            <p className="text-white text-sm">Camera access required for scanning</p>
          </div>
        )}
        
        {scanning && stream && !capturedImage && (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-white text-center p-6 bg-black bg-opacity-30">
            <div className="h-16 w-16 mb-4 animate-pulse border-4 border-white rounded-full flex items-center justify-center">
              <div className="h-12 w-12 rounded-full bg-accent/50"></div>
            </div>
            <h3 className="text-xl font-bold font-poppins">Scanning in progress...</h3>
            <p className="mt-2">Move your camera slowly around the room</p>
          </div>
        )}
      </div>
      
      {stream && !capturedImage && (
        <div className="bg-neutral-800 text-neutral-100 py-2 px-4 text-sm flex justify-between items-center">
          <span>{roomInfo || "Position camera to scan room"}</span>
          <div className="flex space-x-3">
            <button 
              className="p-1 hover:text-white" 
              onClick={handleCapture}
              title="Take photo"
            >
              <Camera className="h-5 w-5" />
            </button>
            <button 
              className="p-1 hover:text-white"
              title="Record video"
            >
              <Video className="h-5 w-5" />
            </button>
            <button 
              className="p-1 hover:text-white"
              title="Copy room measurements"
            >
              <Copy className="h-5 w-5" />
            </button>
          </div>
        </div>
      )}
      
      {capturedImage && (
        <div className="bg-neutral-800 text-neutral-100 py-2 px-4 text-sm flex justify-between items-center">
          <span>Room captured successfully</span>
          <div className="text-success flex items-center">
            <Check className="h-4 w-4 mr-1" />
            <span>Ready for measurements</span>
          </div>
        </div>
      )}
      
      {/* Hidden canvas used for capturing images */}
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
}
