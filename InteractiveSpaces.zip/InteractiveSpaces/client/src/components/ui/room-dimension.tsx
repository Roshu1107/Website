import React from "react";

interface DimensionLineProps {
  value: string;
  orientation: "horizontal" | "vertical";
  position: {
    top?: string | number;
    left?: string | number;
    right?: string | number;
    bottom?: string | number;
  };
  length: string | number;
}

export function DimensionLine({
  value,
  orientation,
  position,
  length
}: DimensionLineProps) {
  const styleProps = {
    ...position,
    [orientation === "horizontal" ? "width" : "height"]: length
  };

  return (
    <div 
      className={`dimension-line ${orientation === "horizontal" ? "horizontal-line" : "vertical-line"}`}
      style={styleProps}
    >
      {value}
    </div>
  );
}

interface RoomDimensionsProps {
  width: string;
  height: string;
  widthPosition?: {
    top?: string | number;
    left?: string | number;
  };
  heightPosition?: {
    top?: string | number;
    left?: string | number;
  };
  widthLength?: string | number;
  heightLength?: string | number;
}

export function RoomDimensions({
  width,
  height,
  widthPosition = { top: 20, left: 20 },
  heightPosition = { left: 20, top: 40 },
  widthLength = "40%",
  heightLength = "30%"
}: RoomDimensionsProps) {
  return (
    <>
      <DimensionLine
        value={width}
        orientation="horizontal"
        position={widthPosition}
        length={widthLength}
      />
      <DimensionLine
        value={height}
        orientation="vertical"
        position={heightPosition}
        length={heightLength}
      />
    </>
  );
}
