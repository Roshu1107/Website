import React from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function CtaSection() {
  return (
    <section className="relative py-16 bg-primary">
      <div className="absolute inset-0 opacity-20">
        <img 
          src="https://images.unsplash.com/photo-1615529328331-f8917597711f?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&h=800" 
          alt="" 
          className="w-full h-full object-cover" 
        />
      </div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl font-extrabold text-white font-poppins sm:text-4xl">
          Ready to transform your space?
        </h2>
        <p className="mt-4 text-xl text-white opacity-90 max-w-2xl mx-auto">
          Sign up today and start planning your perfect room layout with our AI-powered tools.
        </p>
        <div className="mt-8 flex justify-center">
          <div className="inline-flex rounded-md shadow">
            <Link href="/sign-up">
              <Button 
                size="lg" 
                variant="secondary" 
                className="bg-white text-primary hover:bg-neutral-100"
              >
                Get Started Free
              </Button>
            </Link>
          </div>
          <div className="ml-3 inline-flex">
            <Button 
              size="lg" 
              className="border-transparent text-white bg-primary-light hover:bg-primary"
            >
              Watch Demo
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
