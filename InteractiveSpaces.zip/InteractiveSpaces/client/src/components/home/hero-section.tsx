import React from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Play } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="relative py-8 lg:py-16 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-12 lg:gap-8">
          <div className="lg:col-span-6">
            <h1 className="text-4xl font-extrabold text-neutral-900 sm:text-5xl md:text-6xl font-poppins mb-8">
              Plan Your Perfect <span className="text-primary">Room Layout</span> Instantly
            </h1>
            <p className="mt-3 text-base text-neutral-600 sm:mt-5 sm:text-lg md:text-xl">
              Scan your room, place furniture, and get AI recommendations for the perfect fit. 
              No more guesswork when buying new pieces or rearranging your space.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row sm:gap-4">
              <Link href="/room-scanner">
                <Button size="lg" className="bg-primary hover:bg-primary-dark text-white">
                  Start Scanning
                </Button>
              </Link>
              <Button 
                variant="outline" 
                size="lg" 
                className="mt-3 sm:mt-0 text-primary border-primary hover:bg-neutral-100"
              >
                Watch Demo
              </Button>
            </div>
            <div className="mt-8 flex items-center">
              <div className="flex -space-x-2 mr-3">
                <div className="inline-block h-10 w-10 rounded-full ring-2 ring-white bg-neutral-300 overflow-hidden">
                  <svg viewBox="0 0 24 24" fill="none" className="h-full w-full text-neutral-500">
                    <path fillRule="evenodd" clipRule="evenodd" d="M12 18C15.3137 18 18 15.3137 18 12C18 8.68629 15.3137 6 12 6C8.68629 6 6 8.68629 6 12C6 15.3137 8.68629 18 12 18ZM12 20C16.4183 20 20 16.4183 20 12C20 7.58172 16.4183 4 12 4C7.58172 4 4 7.58172 4 12C4 16.4183 7.58172 20 12 20Z" fill="currentColor"/>
                    <path fillRule="evenodd" clipRule="evenodd" d="M12 14C13.1046 14 14 13.1046 14 12C14 10.8954 13.1046 10 12 10C10.8954 10 10 10.8954 10 12C10 13.1046 10.8954 14 12 14ZM12 16C14.2091 16 16 14.2091 16 12C16 9.79086 14.2091 8 12 8C9.79086 8 8 9.79086 8 12C8 14.2091 9.79086 16 12 16Z" fill="currentColor"/>
                  </svg>
                </div>
                <div className="inline-block h-10 w-10 rounded-full ring-2 ring-white bg-neutral-300 overflow-hidden">
                  <svg viewBox="0 0 24 24" fill="none" className="h-full w-full text-neutral-500">
                    <path fillRule="evenodd" clipRule="evenodd" d="M12 18C15.3137 18 18 15.3137 18 12C18 8.68629 15.3137 6 12 6C8.68629 6 6 8.68629 6 12C6 15.3137 8.68629 18 12 18ZM12 20C16.4183 20 20 16.4183 20 12C20 7.58172 16.4183 4 12 4C7.58172 4 4 7.58172 4 12C4 16.4183 7.58172 20 12 20Z" fill="currentColor"/>
                    <path fillRule="evenodd" clipRule="evenodd" d="M12 14C13.1046 14 14 13.1046 14 12C14 10.8954 13.1046 10 12 10C10.8954 10 10 10.8954 10 12C10 13.1046 10.8954 14 12 14ZM12 16C14.2091 16 16 14.2091 16 12C16 9.79086 14.2091 8 12 8C9.79086 8 8 9.79086 8 12C8 14.2091 9.79086 16 12 16Z" fill="currentColor"/>
                  </svg>
                </div>
                <div className="inline-block h-10 w-10 rounded-full ring-2 ring-white bg-neutral-300 overflow-hidden">
                  <svg viewBox="0 0 24 24" fill="none" className="h-full w-full text-neutral-500">
                    <path fillRule="evenodd" clipRule="evenodd" d="M12 18C15.3137 18 18 15.3137 18 12C18 8.68629 15.3137 6 12 6C8.68629 6 6 8.68629 6 12C6 15.3137 8.68629 18 12 18ZM12 20C16.4183 20 20 16.4183 20 12C20 7.58172 16.4183 4 12 4C7.58172 4 4 7.58172 4 12C4 16.4183 7.58172 20 12 20Z" fill="currentColor"/>
                    <path fillRule="evenodd" clipRule="evenodd" d="M12 14C13.1046 14 14 13.1046 14 12C14 10.8954 13.1046 10 12 10C10.8954 10 10 10.8954 10 12C10 13.1046 10.8954 14 12 14ZM12 16C14.2091 16 16 14.2091 16 12C16 9.79086 14.2091 8 12 8C9.79086 8 8 9.79086 8 12C8 14.2091 9.79086 16 12 16Z" fill="currentColor"/>
                  </svg>
                </div>
              </div>
              <span className="text-sm text-neutral-600">Join <strong>2,500+</strong> users optimizing their spaces</span>
            </div>
          </div>
          <div className="mt-12 relative lg:mt-0 lg:col-span-6">
            <div className="relative">
              <img 
                className="w-full rounded-xl shadow-xl" 
                src="https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Modern living room design" 
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-transparent rounded-xl"></div>
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                <button className="bg-white/90 hover:bg-white transition rounded-full p-3 shadow-lg">
                  <Play className="h-10 w-10 text-primary" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
