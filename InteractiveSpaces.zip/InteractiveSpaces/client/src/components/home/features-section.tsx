import React from "react";
import { Camera, Package, Clipboard, BarChart3, MoveVertical, Image } from "lucide-react";

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  color: "primary" | "secondary" | "accent";
}

function FeatureCard({ icon, title, description, color }: FeatureCardProps) {
  const colorClasses = {
    primary: "bg-primary",
    secondary: "bg-secondary",
    accent: "bg-accent"
  };

  return (
    <div className="pt-6">
      <div className="flow-root bg-neutral-50 rounded-lg px-6 pb-8">
        <div className="-mt-6">
          <div>
            <span className={`inline-flex items-center justify-center p-3 ${colorClasses[color]} rounded-md shadow-lg`}>
              {icon}
            </span>
          </div>
          <h3 className="mt-8 text-lg font-medium text-neutral-900 tracking-tight font-poppins">{title}</h3>
          <p className="mt-5 text-base text-neutral-600">
            {description}
          </p>
        </div>
      </div>
    </div>
  );
}

export default function FeaturesSection() {
  const features = [
    {
      icon: <Camera className="h-6 w-6 text-white" />,
      title: "Real-Time Room Scanning",
      description: "Scan your room using your device's camera. Our AI recognizes your space dimensions and creates a digital map for planning.",
      color: "primary"
    },
    {
      icon: <Package className="h-6 w-6 text-white" />,
      title: "Object Placement Testing",
      description: "Upload a photo of any furniture or object and test if it fits in your space, both physically and aesthetically.",
      color: "secondary"
    },
    {
      icon: <Clipboard className="h-6 w-6 text-white" />,
      title: "AI Recommendations",
      description: "Get intelligent suggestions for furniture placement, styling options, and alternative items that would work better in your space.",
      color: "accent"
    },
    {
      icon: <BarChart3 className="h-6 w-6 text-white" />,
      title: "Accurate Measurements",
      description: "Advanced depth estimation technology gives you precise measurements of your space and helps calculate if an object will fit.",
      color: "primary"
    },
    {
      icon: <MoveVertical className="h-6 w-6 text-white" />,
      title: "Interactive Drag & Drop",
      description: "Easily move objects around your virtual room with our intuitive drag and drop interface to find the perfect arrangement.",
      color: "secondary"
    },
    {
      icon: <Image className="h-6 w-6 text-white" />,
      title: "Visual Feedback",
      description: "Get instant visual cues about whether furniture fits - green for a good match, red for a poor fit - along with detailed reasons why.",
      color: "accent"
    }
  ];

  return (
    <section className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center">
          <h2 className="text-base text-accent font-semibold tracking-wide uppercase">Features</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-neutral-900 font-poppins sm:text-4xl">
            Everything you need to design your perfect space
          </p>
          <p className="mt-4 max-w-2xl text-xl text-neutral-600 lg:mx-auto">
            Our AI-powered tools help you visualize, measure, and plan your interior with confidence.
          </p>
        </div>

        <div className="mt-12">
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((feature, index) => (
              <FeatureCard
                key={index}
                icon={feature.icon}
                title={feature.title}
                description={feature.description}
                color={feature.color as "primary" | "secondary" | "accent"}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
