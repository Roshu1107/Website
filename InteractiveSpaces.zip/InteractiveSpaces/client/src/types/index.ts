export interface RoomData {
  id: string;
  name: string;
  dimensions: {
    width: string;
    length: string;
    height: string;
  };
  image: string;
}

export interface FurnitureItem {
  id: string;
  name: string;
  dimensions: string;
  image: string;
  status: 'processing' | 'ready' | 'error';
}

export interface Alternative {
  id: string;
  name: string;
  dimensions: string;
  image: string;
}

export interface AISuggestion {
  id: string;
  furnitureId: string;
  type: 'warning' | 'success' | 'info';
  message: string;
  alternatives?: Alternative[];
  placementTip?: string;
}

export interface User {
  id: number;
  username: string;
}

export interface SavedLayout {
  id: string;
  name: string;
  roomId: string;
  userId: number;
  furniture: Array<FurnitureItem & { position: { x: number, y: number }, rotation: number }>;
  createdAt: string;
}
