import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Add meta tags for better SEO
const metaDescription = document.createElement('meta');
metaDescription.name = 'description';
metaDescription.content = 'RoomFit - Plan your perfect room layout instantly with AI-powered furniture placement, room scanning, and design suggestions.';
document.head.appendChild(metaDescription);

// Add title
const title = document.createElement('title');
title.textContent = 'RoomFit | Smart Space Planning';
document.head.appendChild(title);

// Add open graph tags
const ogTitle = document.createElement('meta');
ogTitle.setAttribute('property', 'og:title');
ogTitle.content = 'RoomFit | Smart Space Planning';
document.head.appendChild(ogTitle);

const ogDesc = document.createElement('meta');
ogDesc.setAttribute('property', 'og:description');
ogDesc.content = 'Transform your living space with AI-powered room planning, furniture placement, and design suggestions.';
document.head.appendChild(ogDesc);

createRoot(document.getElementById("root")!).render(<App />);
