import { useState, useCallback } from "react";
import { tensorflowService, DepthEstimationResult } from "@/lib/tensorflow-service";
import { useToast } from "@/hooks/use-toast";

interface UseDepthEstimationReturn {
  estimateDepth: (imageData: string) => Promise<DepthEstimationResult | null>;
  depthMap: DepthEstimationResult | null;
  isProcessing: boolean;
  error: string | null;
}

export function useDepthEstimation(): UseDepthEstimationReturn {
  const [depthMap, setDepthMap] = useState<DepthEstimationResult | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const estimateDepth = useCallback(async (imageData: string): Promise<DepthEstimationResult | null> => {
    setIsProcessing(true);
    setError(null);
    
    try {
      const depthResult = await tensorflowService.estimateDepth(imageData);
      setDepthMap(depthResult);
      return depthResult;
    } catch (err) {
      const errorMessage = err instanceof Error 
        ? err.message 
        : "Unknown error during depth estimation";
      
      setError(errorMessage);
      toast({
        title: "Depth estimation failed",
        description: errorMessage,
        variant: "destructive"
      });
      
      return null;
    } finally {
      setIsProcessing(false);
    }
  }, [toast]);

  return {
    estimateDepth,
    depthMap,
    isProcessing,
    error
  };
}
