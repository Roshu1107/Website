import { useState, useCallback } from "react";
import { tensorflowService, ObjectDetectionResult } from "@/lib/tensorflow-service";
import { useToast } from "@/hooks/use-toast";

interface UseObjectDetectionReturn {
  detectObjects: (imageData: string) => Promise<ObjectDetectionResult[]>;
  results: ObjectDetectionResult[] | null;
  isProcessing: boolean;
  error: string | null;
}

export function useObjectDetection(): UseObjectDetectionReturn {
  const [results, setResults] = useState<ObjectDetectionResult[] | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const detectObjects = useCallback(async (imageData: string): Promise<ObjectDetectionResult[]> => {
    setIsProcessing(true);
    setError(null);
    
    try {
      const detections = await tensorflowService.detectObjects(imageData);
      setResults(detections);
      return detections;
    } catch (err) {
      const errorMessage = err instanceof Error 
        ? err.message 
        : "Unknown error during object detection";
      
      setError(errorMessage);
      toast({
        title: "Detection failed",
        description: errorMessage,
        variant: "destructive"
      });
      
      return [];
    } finally {
      setIsProcessing(false);
    }
  }, [toast]);

  return {
    detectObjects,
    results,
    isProcessing,
    error
  };
}
