import { 
  users, rooms, furniture, layouts,
  type User, type InsertUser,
  type Room, type InsertRoom,
  type Furniture, type InsertFurniture,
  type Layout, type InsertLayout
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

// Interface for all storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Room operations
  getRoom(id: number): Promise<Room | undefined>;
  getRoomsByUserId(userId: number): Promise<Room[]>;
  createRoom(room: InsertRoom): Promise<Room>;
  
  // Furniture operations
  getFurniture(id: number): Promise<Furniture | undefined>;
  getFurnitureByUserId(userId: number): Promise<Furniture[]>;
  createFurniture(furniture: InsertFurniture): Promise<Furniture>;
  
  // Layout operations
  getLayout(id: number): Promise<Layout | undefined>;
  getLayoutsByUserId(userId: number): Promise<Layout[]>;
  getLayoutsByRoomId(roomId: number): Promise<Layout[]>;
  createLayout(layout: InsertLayout): Promise<Layout>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  // Room operations
  async getRoom(id: number): Promise<Room | undefined> {
    const [room] = await db.select().from(rooms).where(eq(rooms.id, id));
    return room || undefined;
  }
  
  async getRoomsByUserId(userId: number): Promise<Room[]> {
    return await db.select().from(rooms).where(eq(rooms.userId, userId));
  }
  
  async createRoom(room: InsertRoom): Promise<Room> {
    const [newRoom] = await db
      .insert(rooms)
      .values(room)
      .returning();
    return newRoom;
  }
  
  // Furniture operations
  async getFurniture(id: number): Promise<Furniture | undefined> {
    const [item] = await db.select().from(furniture).where(eq(furniture.id, id));
    return item || undefined;
  }
  
  async getFurnitureByUserId(userId: number): Promise<Furniture[]> {
    return await db.select().from(furniture).where(eq(furniture.userId, userId));
  }
  
  async createFurniture(item: InsertFurniture): Promise<Furniture> {
    const [newItem] = await db
      .insert(furniture)
      .values(item)
      .returning();
    return newItem;
  }
  
  // Layout operations
  async getLayout(id: number): Promise<Layout | undefined> {
    const [layout] = await db.select().from(layouts).where(eq(layouts.id, id));
    return layout || undefined;
  }
  
  async getLayoutsByUserId(userId: number): Promise<Layout[]> {
    return await db.select().from(layouts).where(eq(layouts.userId, userId));
  }
  
  async getLayoutsByRoomId(roomId: number): Promise<Layout[]> {
    return await db.select().from(layouts).where(eq(layouts.roomId, roomId));
  }
  
  async createLayout(layout: InsertLayout): Promise<Layout> {
    const [newLayout] = await db
      .insert(layouts)
      .values(layout)
      .returning();
    return newLayout;
  }
}

export const storage = new DatabaseStorage();
